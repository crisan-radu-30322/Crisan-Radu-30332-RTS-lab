package Test;

import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CyclicBarrier;
import java.util.concurrent.Semaphore;


public class test1 {
    public static void main(String args[]) throws BrokenBarrierException, InterruptedException {

        CyclicBarrier barrier = new CyclicBarrier(2);
        Semaphore semaphore = new Semaphore(3);
        Integer monitor1 = new Integer(1);

        ExecThread t1 = new ExecThread(barrier, semaphore, monitor1, 2, 4, 4, 6);
        ExecThreadMonitor t2 = new ExecThreadMonitor(barrier, semaphore, monitor1, 3, 6, 3,2,5);

        t1.start();
        t2.start();
    }
}


class ExecThread extends Thread{
    Semaphore semaphore;

    int activityMin, activityMax, sleep_min, sleep_max;

    CyclicBarrier barrier;
    Integer monitor1;

    public ExecThread(CyclicBarrier barrier,Semaphore semaphore, Integer monitor1, int activityMin, int activityMax, int sleep_min, int sleep_max){
        this.barrier =barrier;
        this.semaphore=semaphore;
        this.activityMin=activityMin;
        this.activityMax=activityMax;
        this.monitor1 = monitor1;
        this.sleep_min = sleep_min;
        this.sleep_max = sleep_max;
    }

    public void run() {

        while(true) {
            System.out.println(this.getName() + " State 1");
            try {
                this.semaphore.acquire(2);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
            System.out.println(this.getName() + " State 2");
            int k = (int) Math.round(Math.random() * (activityMax - activityMin) + activityMin);
            for (int i = 0; i < k * 100000; i++) {
                i++;
                i--;
            }

            System.out.println(this.getName() + " State 3");

            this.semaphore.release(2);



            synchronized (monitor1) {

                try {
                    monitor1.wait();

                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
                try{
                    Thread.sleep(Math.round(Math.random() * (sleep_max - sleep_min) + sleep_min) * 500);
                } catch(InterruptedException e)
                {
                    throw new RuntimeException(e);
                }

                System.out.println(this.getName() + " State 4");

                try {
                    barrier.await();
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                } catch (BrokenBarrierException e) {
                    throw new RuntimeException(e);
                }
            }
        }

    }

}

class ExecThreadMonitor extends Thread {
    Semaphore semaphore;

    int activityMin, activityMax, sleepVal, sleep_min, sleep_max;

    CyclicBarrier barrier;
    Integer monitor1;

    public ExecThreadMonitor(CyclicBarrier barrier,Semaphore semaphore, Integer monitor1, int activityMin, int activityMax, int sleepVal,int sleep_min,int sleep_max){
        this.barrier =barrier;
        this.semaphore=semaphore;
        this.activityMin=activityMin;
        this.activityMax=activityMax;
        this.sleepVal=sleepVal;
        this.monitor1 = monitor1;
        this.sleep_min = sleep_min;
        this.sleep_max = sleep_max;

    }

    public void run() {

        while (true) {
            System.out.println(this.getName() + " - STATE 1");

            try {
                this.semaphore.acquire(3);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }

            synchronized (monitor1) {

                monitor1.notify();
            }

            System.out.println(this.getName() + " - STATE 2");

            int k = (int) Math.round(Math.random() * (activityMax - activityMin) + activityMin);

            for (int i = 0; i < k * 100000; i++) {
                i++;
                i--;
            }


            try {
                Thread.sleep(500 * sleepVal);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }

            System.out.println(this.getName() + " - STATE 3");


            this.semaphore.release(3);
            try {
                Thread.sleep(Math.round(Math.random() * (sleep_max - sleep_min) + sleep_min) * 500);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }



            System.out.println(this.getName() + " - STATE 4");

            try {
                barrier.await();
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            } catch (BrokenBarrierException e) {
                throw new RuntimeException(e);
            }

        }
    }

}
