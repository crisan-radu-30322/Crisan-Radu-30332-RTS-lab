package Enumerations;

import java.io.Serializable;

public enum PetriNetState implements Serializable{
	None,
	Started,
	Stopped
}
